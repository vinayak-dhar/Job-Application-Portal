package com.jobportal.employer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
